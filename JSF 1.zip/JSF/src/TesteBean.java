import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean(name="tCCBean")
@ViewScoped
public class TesteBean {
	private String nome;
	
	public TesteBean(){
		this.nome = "Joel";
		
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}

}
