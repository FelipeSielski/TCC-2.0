
import java.util.List;

import com.vogella.build.maven.java.persistencia.entidade.Usuario;
import com.vogella.build.maven.java.persistencia.jdbc.UsuarioDAO;

public class TestUsuarioDAO {

	public static void main(String[] args) {
//		Coloca a fun��o que quer executar
//		testeCadastrar();
//		testeAlterar();
//		testeExcluir();
//		testeSalvar();
//		testeBuscarTodos();
		
		testeAutenticar();
		
	}
	
	
	private static void testeAutenticar() {
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		
		Usuario usu = new Usuario();
//		Se tiver o login jao e a senha 123 ent�o volta o id, nome, login, e senha , sen�o volta null
		usu.setLogin("jao");
		usu.setSenha("123");
		Usuario usuRetorno = usuarioDAO.autenticar(usu);
		System.out.println(usuRetorno);
		
		
	}


	private static void testeBuscarporId() {
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		Usuario usuario = usuarioDAO.buscarPorId(2);
		System.out.println(usuario);
		
	}
	private static void testeBuscarTodos() {
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		List <Usuario> lista = usuarioDAO.buscarTodos();
		for (Usuario u: lista){
		System.out.println(u);
		}
	}


	public static void testeAlterar(){
		//Criando o usu�rio
				Usuario usu = new Usuario();
				usu.setId(4);
				usu.setNome("J�oz�o da silva sauro");
				usu.setLogin("ajsiis");
				usu.setSenha("123345678");
				//Cadastrando usu�rio no banco de dados
				UsuarioDAO usuDAO = new UsuarioDAO();
				usuDAO.alterar(usu);
				
				System.out.println("Alterado com sucesso.");
	}
	
	
	public static void testeCadastrar(){
		//Criando o usu�rio
				Usuario usu = new Usuario();
				usu.setNome("J�oo");
				usu.setLogin("jao");
				usu.setSenha("123");
				//Cadastrando usu�rio no banco de dados
				UsuarioDAO usuDAO = new UsuarioDAO();
				usuDAO.cadastrar(usu);
				
				System.out.println("cadastrado com sucesso.");
	}
	
	public static void testeExcluir(){
		//Criando o usu�rio
				Usuario usu = new Usuario();
				usu.setId(4); /*qual id da base vc quer excluir.*/
			//Excluindo usu�rio no banco de dados
				UsuarioDAO usuDAO = new UsuarioDAO();
				usuDAO.excluir(usu);
				
				System.out.println("Excluido com sucesso.");
	}
	public static void testeSalvar(){
		Usuario usuario = new Usuario();
		usuario.setId(null);
		usuario.setNome("Vilmar");
		usuario.setLogin("Vilmar.silva");
		usuario.setSenha("34er435");
		
//		Salva usuario no banco de dados
		UsuarioDAO usuDAO = new UsuarioDAO();
		usuDAO.salvar(usuario);
		System.out.println("Salvo com sucesso");
		
	}
}
