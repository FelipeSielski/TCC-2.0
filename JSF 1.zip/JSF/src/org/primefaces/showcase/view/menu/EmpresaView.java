package org.primefaces.showcase.view.menu;
 
import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
 
@ManagedBean (name = "EmpresaBean")
public class EmpresaView {
     
    private MenuModel model;
 
    @PostConstruct
    public void init() {
    	System.out.println("Entrou EmpresaView.java");
        model = new DefaultMenuModel();
         
        //First submenu
        DefaultSubMenu firstSubmenu = new DefaultSubMenu("Dynamic Submenu");
         
        DefaultMenuItem item = new DefaultMenuItem("External");
        item.setUrl("http://www.primefaces.org");
        item.setIcon("ui-icon-home");
        firstSubmenu.addElement(item);
         
        model.addElement(firstSubmenu);
         
        //Second submenu
        DefaultSubMenu secondSubmenu = new DefaultSubMenu("Dynamic Actions");
 
//        item = new DefaultMenuItem("Colaborador");
//        item.setIcon("ui-icon-disk");
//        item.setCommand("#{menuBean.colaborador}");
//        item.setUpdate("messages");
//        secondSubmenu.addElement(item);
        
        item = new DefaultMenuItem("Empresa");
        item.setIcon("ui-icon-disk");
        item.setCommand("#{EmpresaBean.empresa}");
        item.setUpdate("messages");
        secondSubmenu.addElement(item);
         
        item = new DefaultMenuItem("Delete");
        item.setIcon("ui-icon-close");
        item.setCommand("#{menuBean.delete}");
        item.setAjax(false);
        secondSubmenu.addElement(item);
         
        item = new DefaultMenuItem("Redirect");
        item.setIcon("ui-icon-search");
        item.setCommand("#{menuBean.redirect}");
        secondSubmenu.addElement(item);
 
        model.addElement(secondSubmenu);
    }
 
    public MenuModel getModel() {
        return model;
    }   
     
    public void colaborador() throws IOException {
    	System.out.println("Cadastrar colaborador/EmpresaView.java");
        addMessage("Success", "Data saved");
        FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/JSF/cadastroColaborador.jsf");
        System.out.println("foi para o site");
    }
    
    public void ioge() throws IOException {
    	System.out.println("Cadastrar ioge");
        addMessage("Success", "Data saved");
        FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/JSF/cadastroIOGE.jsf");
    }
    public void empresa() throws IOException {
    	System.out.println("Cadastrar empresa / EmpresaView.java");
        addMessage("Success", "Data saved");
        FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/JSF/cadastroEmpresa.jsf");
    }
     
    public void update() {
        addMessage("Success", "Data updated");
    }
     
    public void delete() {
        addMessage("Success", "Data deleted");
    }
     
    public void addMessage(String summary, String detail) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary, detail);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
}