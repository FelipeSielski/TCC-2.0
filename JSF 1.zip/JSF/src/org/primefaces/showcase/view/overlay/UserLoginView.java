package org.primefaces.showcase.view.overlay;

import java.io.IOException;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
 
import org.primefaces.context.RequestContext;

@ManagedBean(name = "Bean")

public class UserLoginView {
     
    private String username;
     
    private String password;
 
    public String getUsername() {
        return username;
    }
 
    public void setUsername(String username) {
        this.username = username;
    }
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }
    public void addMessage(String summary) {
        FacesMessage message = new FacesMessage(FacesMessage.SEVERITY_INFO, summary,  null);
        FacesContext.getCurrentInstance().addMessage(null, message);
    }
    public void login(ActionEvent event) throws IOException {
        RequestContext context = RequestContext.getCurrentInstance();
        FacesMessage message = null;
        boolean loggedIn = false;
         
        if(username != null && username.equals("Felipe") && password != null && password.equals("felipe")) {
        	System.out.println("Entrou aqui");
            loggedIn = true;  
          FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/JSF/menu.jsf");
          addMessage("Welcome to Primefaces!!");
          message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Logou", "Logou");
          		           
        } 
        if(username.equals("oi") && password.equals("oi")) {
  			System.out.println("Entrou segundo IF");
  			loggedIn = true;  
  				FacesContext.getCurrentInstance().getExternalContext().redirect("http://localhost:8080/JSF/menuImplementador.jsf");
  				 message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Logou", "Logou");
  
    
        	}
        else {
            loggedIn = false;
            message = new FacesMessage(FacesMessage.SEVERITY_WARN, "Erro no Login", "Dados inv�lidos");
        }
        
    
         
        FacesContext.getCurrentInstance().addMessage(null, message);
        context.addCallbackParam("loggedIn", loggedIn);
    }   
}